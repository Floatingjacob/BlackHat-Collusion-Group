﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        Button1 = New Button()
        Button2 = New Button()
        Btn = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        Button8 = New Button()
        Button9 = New Button()
        Button10 = New Button()
        Button11 = New Button()
        Button12 = New Button()
        Button13 = New Button()
        Button14 = New Button()
        Button15 = New Button()
        Button16 = New Button()
        Button17 = New Button()
        Button18 = New Button()
        Button19 = New Button()
        Button20 = New Button()
        Label1 = New Label()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(24, 62)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(296, 23)
        TextBox1.TabIndex = 0
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Stencil", 20F)
        Button1.Location = New Point(264, 132)
        Button1.Name = "Button1"
        Button1.Size = New Size(55, 71)
        Button1.TabIndex = 1
        Button1.Text = "÷"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Stencil", 8.25F)
        Button2.Location = New Point(104, 91)
        Button2.Name = "Button2"
        Button2.Size = New Size(75, 35)
        Button2.TabIndex = 2
        Button2.Text = "Button2"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Btn
        ' 
        Btn.Font = New Font("Stencil", 20F)
        Btn.Location = New Point(104, 363)
        Btn.Name = "Btn"
        Btn.Size = New Size(75, 71)
        Btn.TabIndex = 3
        Btn.Text = "."
        Btn.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Font = New Font("Stencil", 20F)
        Button4.Location = New Point(184, 286)
        Button4.Name = "Button4"
        Button4.Size = New Size(75, 71)
        Button4.TabIndex = 4
        Button4.Text = "3"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Font = New Font("Stencil", 20F)
        Button5.Location = New Point(184, 209)
        Button5.Name = "Button5"
        Button5.Size = New Size(75, 71)
        Button5.TabIndex = 5
        Button5.Text = "6"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Font = New Font("Stencil", 20F)
        Button6.Location = New Point(104, 209)
        Button6.Name = "Button6"
        Button6.Size = New Size(75, 71)
        Button6.TabIndex = 6
        Button6.Text = "5"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Font = New Font("Stencil", 20F)
        Button7.Location = New Point(24, 132)
        Button7.Name = "Button7"
        Button7.Size = New Size(75, 71)
        Button7.TabIndex = 7
        Button7.Text = "7"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Font = New Font("Stencil", 20F)
        Button8.Location = New Point(24, 363)
        Button8.Name = "Button8"
        Button8.Size = New Size(75, 71)
        Button8.TabIndex = 8
        Button8.Text = "0"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button9
        ' 
        Button9.Font = New Font("Stencil", 20F)
        Button9.Location = New Point(264, 286)
        Button9.Name = "Button9"
        Button9.Size = New Size(55, 71)
        Button9.TabIndex = 9
        Button9.Text = "+"
        Button9.UseVisualStyleBackColor = True
        ' 
        ' Button10
        ' 
        Button10.Font = New Font("Stencil", 20F)
        Button10.Location = New Point(264, 209)
        Button10.Name = "Button10"
        Button10.Size = New Size(55, 71)
        Button10.TabIndex = 10
        Button10.Text = "×"
        Button10.UseVisualStyleBackColor = True
        ' 
        ' Button11
        ' 
        Button11.Font = New Font("Stencil", 20F)
        Button11.Location = New Point(24, 209)
        Button11.Name = "Button11"
        Button11.Size = New Size(75, 71)
        Button11.TabIndex = 11
        Button11.Text = "4"
        Button11.UseVisualStyleBackColor = True
        ' 
        ' Button12
        ' 
        Button12.Font = New Font("Stencil", 8.25F)
        Button12.Location = New Point(264, 91)
        Button12.Name = "Button12"
        Button12.Size = New Size(55, 35)
        Button12.TabIndex = 12
        Button12.Text = "Clear"
        Button12.UseVisualStyleBackColor = True
        ' 
        ' Button13
        ' 
        Button13.Font = New Font("Stencil", 8.25F)
        Button13.Location = New Point(24, 91)
        Button13.Name = "Button13"
        Button13.Size = New Size(75, 35)
        Button13.TabIndex = 14
        Button13.Text = "Button13"
        Button13.UseVisualStyleBackColor = True
        ' 
        ' Button14
        ' 
        Button14.Font = New Font("Stencil", 20F)
        Button14.Location = New Point(104, 132)
        Button14.Name = "Button14"
        Button14.Size = New Size(75, 71)
        Button14.TabIndex = 15
        Button14.Text = "8"
        Button14.UseVisualStyleBackColor = True
        ' 
        ' Button15
        ' 
        Button15.Font = New Font("Stencil", 8.25F)
        Button15.Location = New Point(184, 91)
        Button15.Name = "Button15"
        Button15.Size = New Size(75, 35)
        Button15.TabIndex = 16
        Button15.Text = "Button15"
        Button15.UseVisualStyleBackColor = True
        ' 
        ' Button16
        ' 
        Button16.Font = New Font("Stencil", 20F)
        Button16.Location = New Point(24, 286)
        Button16.Name = "Button16"
        Button16.Size = New Size(75, 71)
        Button16.TabIndex = 17
        Button16.Text = "1"
        Button16.UseVisualStyleBackColor = True
        ' 
        ' Button17
        ' 
        Button17.Font = New Font("Stencil", 20F)
        Button17.Location = New Point(184, 132)
        Button17.Name = "Button17"
        Button17.Size = New Size(75, 71)
        Button17.TabIndex = 18
        Button17.Text = "9"
        Button17.UseVisualStyleBackColor = True
        ' 
        ' Button18
        ' 
        Button18.Font = New Font("Stencil", 20F)
        Button18.Location = New Point(104, 286)
        Button18.Name = "Button18"
        Button18.Size = New Size(75, 71)
        Button18.TabIndex = 19
        Button18.Text = "2"
        Button18.UseVisualStyleBackColor = True
        ' 
        ' Button19
        ' 
        Button19.Font = New Font("Stencil", 20F)
        Button19.Location = New Point(264, 363)
        Button19.Name = "Button19"
        Button19.Size = New Size(55, 71)
        Button19.TabIndex = 20
        Button19.Text = "=" & vbCrLf
        Button19.UseVisualStyleBackColor = True
        ' 
        ' Button20
        ' 
        Button20.Font = New Font("Stencil", 8.25F)
        Button20.Location = New Point(184, 363)
        Button20.Name = "Button20"
        Button20.Size = New Size(75, 71)
        Button20.TabIndex = 21
        Button20.Text = "Button20"
        Button20.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Old English Text MT", 25F)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(24, 16)
        Label1.Name = "Label1"
        Label1.Size = New Size(292, 40)
        Label1.TabIndex = 22
        Label1.Text = "CALCULATOR"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Black
        ClientSize = New Size(341, 464)
        Controls.Add(Label1)
        Controls.Add(Button20)
        Controls.Add(Button19)
        Controls.Add(Button18)
        Controls.Add(Button17)
        Controls.Add(Button16)
        Controls.Add(Button15)
        Controls.Add(Button14)
        Controls.Add(Button13)
        Controls.Add(Button12)
        Controls.Add(Button11)
        Controls.Add(Button10)
        Controls.Add(Button9)
        Controls.Add(Button8)
        Controls.Add(Button7)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(Button4)
        Controls.Add(Btn)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(TextBox1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Btn As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Label1 As Label

End Class
